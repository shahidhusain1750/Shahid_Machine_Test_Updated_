﻿using CODEFIRST.CRUD.Models;

namespace CODEFIRST.CRUD.Interface
{
    public interface ICategoryService
    {
        #region GetAllCategory
        Task<IEnumerable<Category>> GetAll();
        #endregion

        #region AddCategory
        Task Add(Category category);
        #endregion

        #region GetCategoryById
        Task<Category> GetById(int id);
        #endregion

        #region UpdateCatgory
        Task Update(Category category);
        #endregion

        #region DeleteCategory
        Task Delete(int id);
        #endregion 
    }
}
