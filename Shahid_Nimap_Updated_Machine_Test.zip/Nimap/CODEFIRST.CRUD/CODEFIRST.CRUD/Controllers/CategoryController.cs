﻿using CODEFIRST.CRUD.DTO;
using CODEFIRST.CRUD.Interface;
using CODEFIRST.CRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CODEFIRST.CRUD.Controllers
{
    public class CategoryController : Controller
    {

        #region private field read-only field
        private readonly IProductService _productRep;
        private readonly ICategoryService _categoryRepo;

        public CategoryController(IProductService productRep, ICategoryService categoryRepo)
        {
            _productRep = productRep;
            _categoryRepo = categoryRepo;
        }
        #endregion

        #region Index
        public async Task<IActionResult> Index()
        {
            var category = await _categoryRepo.GetAll();
            return View(category);
        }
        #endregion

        #region [Create] - GetRequest
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            // Fetch categories from the repository
            var categories = await _categoryRepo.GetAll(); // Ensure GetAll is async in ICategoryRep
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName");
            return View();
        }
        #endregion

        #region [Create] - PostRequest
        [HttpPost]
        public async Task<IActionResult> Create(CategoryDTO categoryDTO)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Convert CategoryDTO to Category entity
                    var category = new Category
                    {
                        CategoryName = categoryDTO.CategoryName,
                        CategoryId = categoryDTO.CategoryId // Optional if auto-generated
                    };

                    await _categoryRepo.Add(category);

                    // Redirect to ProductController's Index action after successfully adding a category
                    return RedirectToAction("Index", "Product"); // Adjusted here
                }
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ModelState.AddModelError(string.Empty, "An error occurred while creating the category.");
            }

            // Repopulate the category list in case of a model error
            var categories = await _categoryRepo.GetAll();
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName");

            return View(categoryDTO); // Ensure the model passed here is correct
        }
        #endregion
    }
}