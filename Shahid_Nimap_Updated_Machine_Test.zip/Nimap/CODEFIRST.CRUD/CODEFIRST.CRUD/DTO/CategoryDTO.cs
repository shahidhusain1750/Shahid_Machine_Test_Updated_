﻿namespace CODEFIRST.CRUD.DTO
{
    public class CategoryDTO
    {
        public int CategoryId { get; set; } // You might want to use this for the ID
        public string? CategoryName { get; set; } // The name of the category
    }
}
