﻿using CODEFIRST.CRUD.DTO;
using CODEFIRST.CRUD.Interface;
using CODEFIRST.CRUD.Models;
using Microsoft.EntityFrameworkCore;
using X.PagedList; 
using X.PagedList.Extensions;

namespace CODEFIRST.CRUD.Implimentation
{
    public class ProductService : IProductService
    {
        #region Private field for db access
        private readonly MyAppDbContext _context;
        #endregion

        #region Constructor for accessing the field and initializing
        public ProductService(MyAppDbContext context)
        {
            _context = context;
        }
        #endregion

        #region GetAllProducts
        public async Task<IEnumerable<ProductDTO>> GetAll()
        {
            return await _context.Products
                .Include(p => p.Category) // Eager load the Category data
                .Select(p => new ProductDTO
                {
                    ProductId = p.ProductId,
                    ProductName = p.ProductName,
                    CategoryId = p.CategoryId,
                    CategoryName = p.Category.CategoryName
                })
                .ToListAsync();
        }
        #endregion

        #region AddProducts
        public async Task Add(Product product)
        {
            await _context.Products.AddAsync(product);
            await Save();
        }
        #endregion

        #region GetProductsById
        public async Task<ProductDTO?> GetById(int id) 
        {
            try
            {
                var product = await _context.Products
                        .Include(p => p.Category) // Eager load the Category data
                        .Where(p => p.ProductId == id)
                        .Select(p => new ProductDTO
                        {
                            ProductId = p.ProductId,
                            ProductName = p.ProductName,
                            CategoryId = p.CategoryId,
                            CategoryName = p.Category != null ? p.Category.CategoryName : string.Empty // Handle potential null category
                        })
                        .FirstOrDefaultAsync();

                return product; // Return the product which can be null
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving product with ID {id}: {ex.Message}");
                return null; // Return null in case of an error
            }
        }
        #endregion

        #region UpdateProducts
        public async Task Update(ProductDTO model)
        {
            try
            {
                var product = await _context.Products.FindAsync(model.ProductId);
                if (product != null)
                {
                    product.ProductName = model.ProductName;
                    product.CategoryId = model.CategoryId;
                    _context.Products.Update(product);
                    await Save();
                }
            }
            catch (Exception ex)
            {
                // Log the exception details for debugging
                Console.WriteLine($"Error updating product with ID {model.ProductId}: {ex.Message}");
            }
        }
        #endregion

        #region DeleteProducts
        public async Task Delete(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                await Save();
            }
        }
        #endregion

        #region GetPaginatedProducts
        public async Task<IPagedList<ProductDTO>> GetPaginatedProducts(int pageNumber, int pageSize, string searchTerm)
        {
            var query = _context.Products.Include(p => p.Category).AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                query = query.Where(p => p.ProductName.Contains(searchTerm));
            }
            // Ensure we have the correct total count
            var totalCount = await query.CountAsync();

            var products = await query
                .OrderBy(p => p.ProductId)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .Select(p => new ProductDTO
                {
                    ProductId = p.ProductId,
                    ProductName = p.ProductName,
                    CategoryId = p.CategoryId,
                    CategoryName = p.Category != null ? p.Category.CategoryName : "No Category"
                })
                .ToListAsync();

            return new StaticPagedList<ProductDTO>(products, pageNumber, pageSize, totalCount);
        }
        #endregion

        #region GetTotalProductsCount
        public async Task<int> GetTotalProductsCount()
        {
            return await _context.Products.CountAsync();
        }
        #endregion

        #region SearchProductsBaseOnProductName
        public async Task<IEnumerable<ProductDTO>> SearchProductsBaseOnProductName(string searchTerm)
        {
            var products = await _context.Products
                .Include(p => p.Category)
                .Where(p => string.IsNullOrEmpty(searchTerm) || p.ProductName.Contains(searchTerm))
                .Select(p => new ProductDTO
                {
                    ProductId = p.ProductId,
                    ProductName = p.ProductName,
                    CategoryId = p.CategoryId,
                    CategoryName = p.Category != null ? p.Category.CategoryName : "No Category"
                })
                .ToListAsync();
            return products;
        }
        #endregion

        #region Private SaveChanges Method
        private async Task Save()
        {
            await _context.SaveChangesAsync();
        }
        #endregion
    }
}
