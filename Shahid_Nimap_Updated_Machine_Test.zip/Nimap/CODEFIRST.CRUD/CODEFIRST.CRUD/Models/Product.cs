﻿using System.ComponentModel.DataAnnotations;

namespace CODEFIRST.CRUD.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Product Name is required.")]
        [StringLength(100, ErrorMessage = "Product Name cannot be longer than 100 characters.")]
        public string? ProductName { get; set; }


        [Required]
        public int CategoryId { get; set; }
        public Category? Category { get; set; }
    }
}
